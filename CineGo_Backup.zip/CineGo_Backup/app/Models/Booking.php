<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    // Khai báo hằng số ánh dịch trạng thái sang Tiếng Việt
    public const STATUSES = [
        'confirmed' => 'Đã xác nhận',
        'cancelled' => 'Đã hủy',
        'pending'   => 'Đang xử lý',
    ];

    protected $fillable = ['user_id', 'booking_code', 'total_amount', 'status', 'booked_at'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function bookingDetails()
    {
        return $this->hasMany(BookingDetail::class);
    }
}
