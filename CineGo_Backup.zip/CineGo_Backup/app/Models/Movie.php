<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Movie extends Model
{
    protected $fillable = ['title', 'description', 'duration_minutes', 'release_date', 'genre', 'poster', 'status'];

    public function showtimes()
    {
        return $this->hasMany(Showtime::class);
    }
}
