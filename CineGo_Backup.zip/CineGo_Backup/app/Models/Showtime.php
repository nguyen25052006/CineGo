<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Showtime extends Model
{
    protected $fillable = ['movie_id', 'show_date', 'start_time', 'end_time', 'room_name', 'ticket_price', 'total_tickets', 'available_tickets', 'status'];

    public function movie()
    {
        return $this->belongsTo(Movie::class);
    }

    public function bookingDetails()
    {
        return $this->hasMany(BookingDetail::class);
    }
}
