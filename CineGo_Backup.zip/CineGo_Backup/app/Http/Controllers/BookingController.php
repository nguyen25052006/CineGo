<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use App\Models\BookingDetail;
use App\Models\Showtime;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class BookingController extends Controller
{
    public function create(Showtime $showtime)
    {
        return view('booking.create', compact('showtime'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'showtime_id' => 'required|exists:showtimes,id',
            'quantity' => 'required|integer|min:1',
        ]);

        $showtime = Showtime::findOrFail($request->showtime_id);

        if ($request->quantity > $showtime->available_tickets) {
            return back()->withErrors(['quantity' => 'Số lượng vé đặt vượt quá số vé còn lại!']);
        }

        DB::transaction(function () use ($request, $showtime) {
            $unitPrice = $showtime->ticket_price;
            $subtotal = $request->quantity * $unitPrice;

            $booking = Booking::create([
                'user_id' => Auth::id(),
                'booking_code' => 'CINE-' . strtoupper(Str::random(8)),
                'total_amount' => $subtotal,
                'status' => 'confirmed',
                'booked_at' => now(),
            ]);

            BookingDetail::create([
                'booking_id' => $booking->id,
                'showtime_id' => $showtime->id,
                'quantity' => $request->quantity,
                'unit_price' => $unitPrice,
                'subtotal' => $subtotal,
            ]);

            $showtime->decrement('available_tickets', $request->quantity);
        });

        return redirect()->route('booking.history')->with('success', 'Đặt vé thành công!');
    }

    public function history()
    {
        $bookings = Booking::where('user_id', Auth::id())
            ->with('bookingDetails.showtime.movie')
            ->latest()
            ->paginate(5); // Phân trang 5 đơn/trang

        return view('booking.history', compact('bookings'));
    }

    public function show(Booking $booking)
    {
        if ($booking->user_id !== Auth::id() && Auth::user()->role !== 'admin') {
            abort(403);
        }
        $booking->load('bookingDetails.showtime.movie', 'user');
        return view('booking.show', compact('booking'));
    }

    public function adminIndex()
    {
        $bookings = Booking::with('user', 'bookingDetails.showtime.movie')->latest()->paginate(10);
        return view('admin.bookings.index', compact('bookings'));
    }
}
