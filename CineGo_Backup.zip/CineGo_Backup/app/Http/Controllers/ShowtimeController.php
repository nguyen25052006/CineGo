<?php

namespace App\Http\Controllers;

use App\Models\Movie;
use App\Models\Showtime;
use Illuminate\Http\Request;

class ShowtimeController extends Controller
{
    public function adminIndex()
    {
        $showtimes = Showtime::with('movie')->latest()->paginate(10);
        return view('admin.showtimes.index', compact('showtimes'));
    }

    public function create()
    {
        $movies = Movie::where('status', 'showing')->get();
        return view('admin.showtimes.create', compact('movies'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'movie_id' => 'required|exists:movies,id',
            'show_date' => 'required|date',
            'start_time' => 'required',
            'end_time' => 'required',
            'room_name' => 'required|string',
            'ticket_price' => 'required|numeric|min:0',
            'total_tickets' => 'required|integer|min:1',
            'status' => 'required|in:active,inactive',
        ]);

        $data['available_tickets'] = $data['total_tickets'];
        Showtime::create($data);

        return redirect()->route('admin.showtimes.index')->with('success', 'Thêm suất chiếu thành công!');
    }

    public function edit(Showtime $showtime)
    {
        $movies = Movie::all();
        return view('admin.showtimes.edit', compact('showtime', 'movies'));
    }

    public function update(Request $request, Showtime $showtime)
    {
        $data = $request->validate([
            'movie_id' => 'required|exists:movies,id',
            'show_date' => 'required|date',
            'start_time' => 'required',
            'end_time' => 'required',
            'room_name' => 'required|string',
            'ticket_price' => 'required|numeric|min:0',
            'total_tickets' => 'required|integer|min:1',
            'available_tickets' => 'required|integer|lte:total_tickets',
            'status' => 'required|in:active,inactive',
        ]);

        $showtime->update($data);
        return redirect()->route('admin.showtimes.index')->with('success', 'Cập nhật suất chiếu thành công!');
    }

    public function destroy(Showtime $showtime)
    {
        $showtime->delete();
        return redirect()->route('admin.showtimes.index')->with('success', 'Đã xóa suất chiếu!');
    }
}
