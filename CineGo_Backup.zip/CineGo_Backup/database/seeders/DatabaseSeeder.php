<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Movie;
use App\Models\Showtime;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        User::create([
            'name' => 'Quản trị viên Admin',
            'email' => 'admin@gmail.com',
            'password' => Hash::make('admin123'),
            'role' => 'admin',
        ]);

        User::create([
            'name' => 'Nguyễn Hữu Thịnh',
            'email' => 'user@gmail.com',
            'password' => Hash::make('user123'),
            'role' => 'user',
        ]);

        $movie = Movie::create([
            'title' => 'Lật Mặt 7: Một Điều Ước',
            'description' => 'Bộ phim tâm lý gia đình đầy xúc động.',
            'duration_minutes' => 138,
            'release_date' => '2026-04-26',
            'genre' => 'Tâm lý, Gia đình',
            'status' => 'showing',
        ]);

        Showtime::create([
            'movie_id' => $movie->id,
            'show_date' => now()->toDateString(),
            'start_time' => '19:00:00',
            'end_time' => '21:18:00',
            'room_name' => 'Phòng 01 (2D)',
            'ticket_price' => 85000,
            'total_tickets' => 100,
            'available_tickets' => 100,
            'status' => 'active',
        ]);
    }
}
