<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\BookingController;
use App\Http\Controllers\MovieController;
use App\Http\Controllers\ShowtimeController;
use App\Models\Movie;
use App\Models\Showtime;
use App\Models\Booking;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| AUTH ROUTES (Đăng nhập / Đăng ký / Đăng xuất)
|--------------------------------------------------------------------------
*/
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.authenticate');
Route::get('/register', [AuthController::class, 'showRegisterForm'])->name('register');
Route::post('/register', [AuthController::class, 'register'])->name('register.store');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

/*
|--------------------------------------------------------------------------
| USER ROUTES (Dành cho Khách & Người dùng)
|--------------------------------------------------------------------------
*/
Route::get('/', function () {
    $showingMovies = Movie::where('status', 'showing')->take(4)->get();
    $comingSoonMovies = Movie::where('status', 'coming_soon')->take(4)->get();
    return view('home', compact('showingMovies', 'comingSoonMovies'));
})->name('home');

Route::get('/movies', [MovieController::class, 'index'])->name('movies.index');
Route::get('/movies/{movie}', [MovieController::class, 'show'])->name('movies.show');

Route::middleware('auth')->group(function () {
    // Đặt vé (Đồng bộ cả booking.create và bookings.create)
    Route::get('/booking/create/{showtime}', [BookingController::class, 'create'])->name('booking.create');
    Route::get('/bookings/create/{showtime}', [BookingController::class, 'create'])->name('bookings.create');
    
    Route::post('/booking', [BookingController::class, 'store'])->name('booking.store');
    
    // Lịch sử đặt vé (Đồng bộ cả booking.history và bookings.history)
    Route::get('/booking/history', [BookingController::class, 'history'])->name('booking.history');
    Route::get('/bookings/history', [BookingController::class, 'history'])->name('bookings.history');
    
    Route::get('/booking/{booking}', [BookingController::class, 'show'])->name('booking.show');
});

/*
|--------------------------------------------------------------------------
| ADMIN ROUTES (Quản trị viên)
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/dashboard', function () {
        $totalMovies = Movie::count();
        $totalShowtimes = Showtime::count();
        $totalBookings = Booking::count();
        return view('admin.dashboard', compact('totalMovies', 'totalShowtimes', 'totalBookings'));
    })->name('dashboard');

    Route::resource('movies', MovieController::class);
    Route::resource('showtimes', ShowtimeController::class);
    Route::get('/bookings', [BookingController::class, 'adminIndex'])->name('bookings.index');
    Route::get('/bookings/{booking}', [BookingController::class, 'show'])->name('bookings.show');
});