@extends('layouts.admin')

@section('content')
<h3>Thêm Phim Mới</h3>
<form action="{{ route('admin.movies.store') }}" method="POST" enctype="multipart/form-data" class="bg-white p-4 rounded shadow-sm">
    @csrf
    <div class="mb-3">
        <label>Tên phim</label>
        <input type="text" name="title" class="form-control" required>
    </div>
    <div class="mb-3">
        <label>Mô tả</label>
        <textarea name="description" class="form-control" rows="3" required></textarea>
    </div>
    <div class="row">
        <div class="col-md-4 mb-3">
            <label>Thời lượng (phút)</label>
            <input type="number" name="duration_minutes" class="form-control" required>
        </div>
        <div class="col-md-4 mb-3">
            <label>Ngày khởi chiếu</label>
            <input type="date" name="release_date" class="form-control" required>
        </div>
        <div class="col-md-4 mb-3">
            <label>Thể loại</label>
            <input type="text" name="genre" class="form-control" required>
        </div>
    </div>
    <div class="mb-3">
        <label>Trạng thái</label>
        <select name="status" class="form-select">
            <option value="showing">Đang chiếu (showing)</option>
            <option value="coming_soon">Sắp chiếu (coming_soon)</option>
            <option value="ended">Đã kết thúc (ended)</option>
        </select>
    </div>
    <button class="btn btn-success">Lưu lại</button>
    <a href="{{ route('admin.movies.index') }}" class="btn btn-secondary">Hủy</a>
</form>
@endsection