@extends('layouts.admin')

@section('title', 'Bảng Điều Khiển Admin - CineGo')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold text-dark mb-0">Bảng Điều Khiển Quản Trị</h2>
</div>

<div class="row g-4">
    <div class="col-md-4">
        <div class="card bg-primary text-white shadow-sm border-0 h-100">
            <div class="card-body p-4 d-flex align-items-center justify-content-between">
                <div>
                    <h6 class="text-uppercase fw-bold text-white-50 mb-2">Tổng số phim</h6>
                    <h2 class="display-5 fw-bold mb-0">{{ $totalMovies }}</h2>
                </div>
                <i class="bi bi-film fs-1 text-white-50"></i>
            </div>
            <div class="card-footer bg-transparent border-0 pt-0 pb-3">
                <a href="{{ route('admin.movies.index') }}" class="text-white text-decoration-none small fw-bold">Xem chi tiết <i class="bi bi-arrow-right ms-1"></i></a>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card bg-success text-white shadow-sm border-0 h-100">
            <div class="card-body p-4 d-flex align-items-center justify-content-between">
                <div>
                    <h6 class="text-uppercase fw-bold text-white-50 mb-2">Tổng suất chiếu</h6>
                    <h2 class="display-5 fw-bold mb-0">{{ $totalShowtimes }}</h2>
                </div>
                <i class="bi bi-calendar-event fs-1 text-white-50"></i>
            </div>
            <div class="card-footer bg-transparent border-0 pt-0 pb-3">
                <a href="{{ route('admin.showtimes.index') }}" class="text-white text-decoration-none small fw-bold">Xem chi tiết <i class="bi bi-arrow-right ms-1"></i></a>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card bg-warning text-dark shadow-sm border-0 h-100">
            <div class="card-body p-4 d-flex align-items-center justify-content-between">
                <div>
                    <h6 class="text-uppercase fw-bold text-black-50 mb-2">Tổng đơn đặt vé</h6>
                    <h2 class="display-5 fw-bold mb-0">{{ $totalBookings }}</h2>
                </div>
                <i class="bi bi-ticket-perforated fs-1 text-black-50"></i>
            </div>
            <div class="card-footer bg-transparent border-0 pt-0 pb-3">
                <a href="{{ route('admin.bookings.index') }}" class="text-dark text-decoration-none small fw-bold">Xem chi tiết <i class="bi bi-arrow-right ms-1"></i></a>
            </div>
        </div>
    </div>
</div>
@endsection