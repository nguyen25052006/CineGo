<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'CineGo Admin'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
</head>

<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand text-warning fw-bold fs-4" href="<?php echo e(route('admin.dashboard')); ?>">👑 CineGo Admin</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.movies.index')); ?>">Quản lý Phim</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.showtimes.index')); ?>">Quản lý Suất chiếu</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('admin.bookings.index')); ?>">Quản lý Đặt vé</a></li>
                </ul>
                <a href="<?php echo e(route('home')); ?>" class="btn btn-outline-light btn-sm">Về trang chủ</a>
            </div>
        </div>
    </nav>

    <div class="container py-4">
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html><?php /**PATH C:\laragon\www\CineGo_Backup\resources\views/layouts/admin.blade.php ENDPATH**/ ?>